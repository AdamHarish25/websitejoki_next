'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthState } from 'react-firebase-hooks/auth';
import { signOut } from 'firebase/auth';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage } from '@/lib/firebaseConfig';

// Impor komponen dan hook dari Tiptap
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';

// Komponen helper untuk Menu Bar Editor Tiptap
const MenuBar = ({ editor }) => {
  if (!editor) {
    return null;
  }

  // Daftar tombol untuk menu bar
  const menuButtons = [
    { name: 'Bold', action: () => editor.chain().focus().toggleBold().run(), active: 'bold' },
    { name: 'Italic', action: () => editor.chain().focus().toggleItalic().run(), active: 'italic' },
    { name: 'Strike', action: () => editor.chain().focus().toggleStrike().run(), active: 'strike' },
    { name: 'Paragraph', action: () => editor.chain().focus().setParagraph().run(), active: 'paragraph' },
    { name: 'H1', action: () => editor.chain().focus().toggleHeading({ level: 1 }).run(), active: 'heading', level: 1 },
    { name: 'H2', action: () => editor.chain().focus().toggleHeading({ level: 2 }).run(), active: 'heading', level: 2 },
    { name: 'Bullet List', action: () => editor.chain().focus().toggleBulletList().run(), active: 'bulletList' },
    { name: 'Ordered List', action: () => editor.chain().focus().toggleOrderedList().run(), active: 'orderedList' },
  ];

  return (
    <div className="border border-gray-300 rounded-t-md p-2 flex flex-wrap gap-x-3 gap-y-2">
      {menuButtons.map(btn => (
        <button
          key={btn.name}
          type="button"
          onClick={btn.action}
          className={editor.isActive(btn.active, btn.level ? { level: btn.level } : {}) ? 'is-active' : ''}
        >
          {btn.name}
        </button>
      ))}
    </div>
  );
};


export default function AdminDashboard() {
  const [user, loading] = useAuthState(auth);
  const router = useRouter();

  const [title, setTitle] = useState('');
  const [coverImage, setCoverImage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Setup editor Tiptap
  const editor = useEditor({
    extensions: [StarterKit],
    content: '<p>Tulis artikel Anda di sini...</p>',
    editorProps: {
      attributes: {
        class: 'prose max-w-none p-4 border-b border-x border-gray-300 rounded-b-md min-h-[300px] focus:outline-none',
      },
    },
  });

  const handleLogout = async () => {
    await signOut(auth);
    router.push('/admin/login');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const content = editor.getHTML(); // Ambil konten HTML dari Tiptap

    if (!title || content === '<p></p>' || !coverImage) {
      alert("Judul, konten, dan gambar cover wajib diisi!");
      return;
    }
    setIsLoading(true);

    try {
      // 1. Upload gambar ke Firebase Storage
      const imageRef = ref(storage, `articles/${Date.now()}_${coverImage.name}`);
      await uploadBytes(imageRef, coverImage);
      const imageUrl = await getDownloadURL(imageRef);

      // 2. Buat slug dari judul
      const slug = title.toLowerCase()
        .replace(/\s+/g, '-') // Ganti spasi dengan strip
        .replace(/[^a-z0-9-]/g, '') // Hapus karakter non-alphanumeric kecuali strip
        .replace(/--+/g, '-') // Ganti beberapa strip dengan satu
        .replace(/^-+|-+$/g, ''); // Hapus strip di awal dan akhir

      // 3. Simpan data artikel lengkap ke Firestore
      await addDoc(collection(db, "articles"), {
        title: title,
        slug: slug,
        content: content,
        coverImageUrl: imageUrl,
        createdAt: serverTimestamp(),
        author: user.email 
      });

      alert("Artikel berhasil dipublikasikan!");
      // Reset form setelah berhasil
      setTitle('');
      editor.commands.setContent('<p></p>'); // Reset konten editor Tiptap
      setCoverImage(null);
      document.querySelector('input[type="file"]').value = ''; // Cara mudah reset input file
      
    } catch (error) {
      console.error("Error saat publikasi: ", error);
      alert("Gagal mempublikasikan artikel!");
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center p-10">Memverifikasi sesi...</div>;
  }

  if (user) {
    return (
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        <div className="flex justify-between items-center mb-8 border-b pb-4">
          <div>
            <h1 className="text-3xl font-bold">Dashboard Admin</h1>
            <p className="text-gray-500">Selamat datang, {user.email}</p>
          </div>
          <button onClick={handleLogout} className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">
            Logout
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-lg font-medium mb-1">Judul Artikel</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-1">Gambar Cover</label>
            <input
              type="file"
              onChange={(e) => setCoverImage(e.target.files[0])}
              accept="image/png, image/jpeg, image/webp"
              className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-600 hover:file:bg-indigo-100"
              required
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2">Konten</label>
            <MenuBar editor={editor} />
            <EditorContent editor={editor} />
          </div>
          
          <div className="pt-8">
            <button 
              type="submit" 
              disabled={isLoading} 
              className="w-full px-6 py-3 bg-green-600 text-white font-bold rounded-md text-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? 'Memproses...' : 'Publikasikan Artikel'}
            </button>
          </div>
        </form>
      </div>
    );
  }

  // Jika tidak loading dan tidak ada user, return null (akan di-redirect oleh layout)
  return null; 
}