import Image from 'next/image';

export default function ServicesSection() {
  // Data layanan bisa diletakkan di sini atau diambil dari CMS
  const services = [
    { title: "Aplikasi Mobile", description: "Tingkatkan loyalitas pelanggan...", image: "/placeholder.jpg", alt: "Mockup aplikasi mobile" },
    { title: "Website", description: "Ubah pengunjung menjadi pelanggan...", image: "/placeholder.jpg", alt: "Mockup website profesional" },
    { title: "Dashboard", description: "Ambil keputusan bisnis lebih cerdas...", image: "/placeholder.jpg", alt: "Mockup dashboard analitik" },
    { title: "Advertising Online", description: "Dapatkan pelanggan berkualitas secara instan...", image: "/placeholder.jpg", alt: "Iklan Google di halaman pencarian" },
    { title: "Artikel SEO", description: "Dominasi peringkat Google dan bangun kepercayaan...", image: "/placeholder.jpg", alt: "Contoh hasil artikel SEO" },
  ];

  return (
    <section className="bg-green-50/50 py-20">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Layanan Digital</h2>
        <p className="text-lg text-gray-600 mb-12 max-w-2xl mx-auto">Pilihan Jawara!</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Ini adalah contoh untuk 1 card, Anda bisa map datanya */}
          {services.map((service, index) => (
             <div key={index} className="bg-white p-6 rounded-xl shadow-md text-left transition-transform hover:-translate-y-2">
               <div className="relative w-full h-40 mb-4 rounded-lg overflow-hidden">
                 <Image src={service.image} alt={service.alt} fill style={{objectFit: 'contain'}} />
               </div>
               <h3 className="text-xl font-bold mb-2">{service.title}</h3>
               <p className="text-gray-600">{service.description}</p>
             </div>
          ))}
        </div>
      </div>
    </section>
  );
}