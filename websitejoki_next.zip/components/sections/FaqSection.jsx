import FaqItem from '../FaqItem';

export default function FaqSection() {
  const faqs = [
    { q: "Bagaimana alur kerja atau proses kolaborasi dengan tim Anda?", a: "Proses kami sangat transparan..." },
    { q: "Berapa biaya untuk layanan yang Anda tawarkan?", a: "Biaya setiap proyek bersifat unik..." },
    // ... Tambahkan FAQ lainnya
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-6 max-w-3xl">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Frequently Asked Questions (FAQ)</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <FaqItem key={index} question={faq.q} answer={faq.a} />
          ))}
        </div>
      </div>
    </section>
  );
}