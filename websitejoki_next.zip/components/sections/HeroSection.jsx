import Link from 'next/link';
import Image from 'next/image';

export default function HeroSection() {
  return (
    <section className="container mx-auto px-6 py-16 md:py-24">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
            Level up Bisnis Anda dengan <span className="text-green-600">Website, Google Ads, & Aplikasi</span> Sesuai Kebutuhan Anda!
          </h1>
          <p className="text-lg text-gray-600">
            Kami adalah mitra teknologi yang mengembangkan aplikasi kustom, website, dan SEO untuk membantu brand berkembang dan mencapai tujuan bisnis mereka.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Link href="#" className="px-8 py-3 bg-green-600 text-white text-center font-semibold rounded-md hover:bg-green-700 transition-colors">
              Konsultasi Gratis
            </Link>
            <Link href="#" className="px-8 py-3 bg-gray-200 text-gray-800 text-center font-semibold rounded-md hover:bg-gray-300 transition-colors">
              Lihat Layanan
            </Link>
          </div>
          <div className="flex items-center pt-4 text-sm text-gray-500">
            {/* ... Social proof kecil ... */}
          </div>
        </div>
        <div className="relative w-full h-80 md:h-full rounded-xl overflow-hidden shadow-2xl">
           <Image 
             src="/placeholder.jpg" // Ganti dengan path gambar/video Anda
             alt="Tim sedang berkolaborasi dalam sebuah rapat di kantor modern"
             fill
             style={{ objectFit: 'cover' }}
             priority
           />
           <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
             <div className="w-16 h-16 bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
             </div>
           </div>
        </div>
      </div>
    </section>
  );
}