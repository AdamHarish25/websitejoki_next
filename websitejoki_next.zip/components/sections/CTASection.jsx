import Link from 'next/link';
import { FaWhatsapp } from 'react-icons/fa'

export default function CtaSection() {
  return (
    // Section dengan ID "kontak" untuk navigasi dan background hijau
    <section id="kontak" className="bg-green-600">
       <div className="container mx-auto px-6 py-16 md:py-20 text-center text-white">
        
        {/* Judul Utama CTA */}
        <h2 className="text-3xl md:text-4xl font-extrabold mb-6 leading-tight">
            Eksplor Potensi Usahamu dan Mulai Perjalananmu Hari ini.
        </h2>
        
        {/* Tombol Aksi Utama */}
        <Link 
            href="#" 
            className="inline-block px-10 py-4 bg-white text-green-600 font-bold rounded-md hover:bg-gray-100 transition-colors text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1"
        >
            Konsultasi Gratis <FaWhatsapp color='white'/>
        </Link>
       </div>
    </section>
  );
}